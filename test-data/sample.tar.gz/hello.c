/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * hello.c - Sample C file for FOSSology PoC
 *
 * Copyright (C) 2024 FOSSology PoC Authors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#include <stdio.h>

int main(void) {
    printf("Hello from FOSSology K8s PoC!\n");
    return 0;
}
