# SPDX-License-Identifier: MIT
#
# utils.py - Sample Python utility for FOSSology PoC
#
# MIT License
# Copyright (c) 2024 FOSSology PoC Authors
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software.

def greet(name: str) -> str:
    """Return a greeting string."""
    return f"Hello, {name}! From FOSSology K8s PoC."

if __name__ == "__main__":
    print(greet("World"))
